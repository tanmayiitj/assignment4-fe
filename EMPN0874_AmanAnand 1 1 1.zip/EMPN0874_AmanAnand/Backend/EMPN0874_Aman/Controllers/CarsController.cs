using EMPN0874_Aman.Model;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace EMPN0874_Aman.Controllers
{
    public class CarsController : Controller
    {
        private static List<Cars> cars;
        private readonly ILogger<CarsController> _logger;

        public CarsController(ILogger<CarsController> logger)
        {
            _logger = logger;
            cars = LoadCarsFromFile();
        }

        [HttpGet]
        [Route("/GetCars")]
        public async Task<IActionResult> Index()
        {
            return Json(cars);
        }

        [HttpGet]
        [Route("/GetCar/{id}")]
        public IActionResult GetCar(int id)
        {
            Cars car = GetCarFromFile(id);

            return car != null ? Json(car) : Json("Car not found");
        }

        [HttpPost]
        [Route("/AddNewCar")]
        public IActionResult AddNewCar(Cars car)
        {
            List<Cars> cars = LoadCarsFromFile();

            // Find the maximum ID from the existing list of cars
            int maxId = cars.Count > 0 ? cars.Max(e => e.Id) : 0;

            // Set the ID for the new car as 1 plus the maximum ID
            car.Id = maxId + 1;

            cars.Add(car);
            System.IO.File.WriteAllText("CarData.json", JsonConvert.SerializeObject(cars));
            return Json(car);
        }

        [HttpPut]
        [Route("/UpdateCar")]
        public IActionResult UpdateCar(Cars car)
        {
            List<Cars> cars = LoadCarsFromFile();
            Cars carToUpdate = cars.Find(e => e.Id == car.Id);

            if (carToUpdate != null)
            {
                carToUpdate.Name = car.Name;
                carToUpdate.model = car.model;
                carToUpdate.Price = car.Price;
                System.IO.File.WriteAllText("CarData.json", JsonConvert.SerializeObject(cars));
                return Json(carToUpdate);
            }

            return Json("Car not found");
        }

        [HttpDelete]
        [Route("/DeleteCar/{id}")]
        public IActionResult DeleteCar(int id)
        {
            List<Cars> cars = LoadCarsFromFile();
            Cars carToDelete = cars.Find(e => e.Id == id);

            if (carToDelete != null)
            {
                cars.Remove(carToDelete);
                System.IO.File.WriteAllText("CarData.json", JsonConvert.SerializeObject(cars));
                return Json(cars);
            }

            return Json("Car not found");
        }

        private Cars GetCarFromFile(int id)
        {
            List<Cars> cars = LoadCarsFromFile();
            return cars.Find(e => e.Id == id);
        }

        private List<Cars> LoadCarsFromFile()
        {
            string data = System.IO.File.ReadAllText("CarData.json");
            return JsonConvert.DeserializeObject<List<Cars>>(data) ?? new List<Cars>();
        }
    }
}
