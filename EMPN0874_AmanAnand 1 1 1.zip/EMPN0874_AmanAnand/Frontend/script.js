const baseURL = "https://localhost:7067/";
$.ajax({
    url: baseURL + "GetCars/",
    type: "GET",
    success: function (data) {
        data.forEach(car => {
            $('#carTable').append('<tr><td>' + car.id + '</td><td>' + car.name + '</td><td>' + car.model + '</td><td>' + car.price + '</td></tr>');
        });
    },
    error: function (error) {
        console.log(error);
    }
});
$('#searchButton').click(function () {
    var id = $('#searchId').val();
    $.ajax({
        url: baseURL + "GetCar/" + id,
        type: "GET",
        success: function (data) {
            $('#carTable').empty();
            $('#carTable').append('<tr><td>' + data.id + '</td><td>' + data.name + '</td><td>' + data.model + '</td><td>' + data.price + '</td></tr>');
        },
        error: function (error) {
            console.log(error);
        }
    });
});
$('#id').on('input', function () {
    if ($(this).val() !== '') {
        $('#updateButton').prop('disabled', false);
        $('#deleteButton').prop('disabled', false);
    } else {
        $('#updateButton').prop('disabled', true);
        $('#deleteButton').prop('disabled', true);
    }
});
$('#createButton').click(function () {
    var name = $('#Cname').val();
    var model = $('#Cmodel').val();
    var price = $('#Cprice').val();
    var url = baseURL + 'AddNewCar?name=' + encodeURIComponent(name) + '&model=' + encodeURIComponent(model) + '&price=' + encodeURIComponent(price);
    $.ajax({
        url: url,
        type: "POST",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            console.log(data);
            location.reload();
        },
        error: function (error) {
            console.log(error);
        }
    });
});
$('#updateButton').click(function () {
    var id = $('#id').val();
    var name = $('#name').val();
    var model = $('#model').val();
    var price = $('#price').val();
    var url = baseURL + 'UpdateCar?Id=' + encodeURIComponent(id) + '&name=' + encodeURIComponent(name) + '&model=' + encodeURIComponent(model) + '&price=' + encodeURIComponent(price);
    $.ajax({
        url: url,
        type: "PUT",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            console.log(data);
            location.reload();
        },
        error: function (error) {
            console.log(error);
        }
    });
});
$('#deleteButton').click(function () {
    var id = $('#deleteId').val();
    if (id === '') {
        alert('Please enter an ID');
        return;
    }
    $.ajax({
        url: baseURL + 'DeleteCar/' + id,
        type: "DELETE",
        success: function (data) {
            console.log(data);
            $('#carTable').empty();
            data.forEach(car => {
                $('#carTable').append('<tr><td>' + car.id + '</td><td>' + car.name + '</td><td>' + car.model + '</td><td>' + car.price + '</td></tr>');
            });
        },
        error: function (error) {
            console.log(error);
        }
    });
});
